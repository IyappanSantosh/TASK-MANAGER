import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { useQueueStatus } from "@/hooks/useQueueStatus";
import { Clock, CheckCircle, AlertTriangle, Loader, Activity } from "lucide-react";
import { cn } from "@/lib/utils";

export function QueueStatus() {
  const { taskProcessor, imageUpload, emailDispatch, isLoading, hasActiveJobs, totalJobs } = useQueueStatus();

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5" />
            Queue Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="flex items-center justify-between">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-6 w-16" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const queueData = [
    {
      name: 'Task Processor',
      key: 'taskProcessor',
      metrics: taskProcessor,
      icon: <Clock className="w-4 h-4" />,
      description: 'Handles task processing workflows'
    },
    {
      name: 'Image Upload',
      key: 'imageUpload', 
      metrics: imageUpload,
      icon: <CheckCircle className="w-4 h-4" />,
      description: 'Processes image uploads and thumbnails'
    },
    {
      name: 'Email Dispatch',
      key: 'emailDispatch',
      metrics: emailDispatch,
      icon: <AlertTriangle className="w-4 h-4" />,
      description: 'Manages email notifications and retries'
    }
  ];

  const getQueueStatusColor = (metrics: any) => {
    if (!metrics) return 'bg-gray-100 text-gray-600';
    if (metrics.failed > 0) return 'bg-red-100 text-red-600';
    if (metrics.active > 0) return 'bg-blue-100 text-blue-600';
    if (metrics.waiting > 0) return 'bg-yellow-100 text-yellow-600';
    return 'bg-green-100 text-green-600';
  };

  const getQueueStatusText = (metrics: any) => {
    if (!metrics) return 'Unknown';
    if (metrics.failed > 0) return 'Error';
    if (metrics.active > 0) return 'Active';
    if (metrics.waiting > 0) return 'Waiting';
    return 'Idle';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5" />
            Queue Status
          </div>
          {hasActiveJobs && (
            <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
              <Loader className="w-3 h-3 mr-1 animate-spin" />
              {totalJobs} active
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {queueData.map((queue) => {
            const metrics = queue.metrics;
            const totalProcessed = metrics ? metrics.completed + metrics.failed : 0;
            const activePercent = metrics && (metrics.active + metrics.waiting) > 0 
              ? Math.round((metrics.active / (metrics.active + metrics.waiting)) * 100) 
              : 0;

            return (
              <div key={queue.key} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {queue.icon}
                    <div>
                      <h4 className="font-medium text-sm">{queue.name}</h4>
                      <p className="text-xs text-gray-500">{queue.description}</p>
                    </div>
                  </div>
                  <Badge className={cn("text-xs", getQueueStatusColor(metrics))}>
                    {getQueueStatusText(metrics)}
                  </Badge>
                </div>

                {metrics && (
                  <div className="space-y-2">
                    <div className="grid grid-cols-4 gap-2 text-xs">
                      <div className="text-center">
                        <div className="font-medium text-blue-600">{metrics.waiting}</div>
                        <div className="text-gray-500">Waiting</div>
                      </div>
                      <div className="text-center">
                        <div className="font-medium text-yellow-600">{metrics.active}</div>
                        <div className="text-gray-500">Active</div>
                      </div>
                      <div className="text-center">
                        <div className="font-medium text-green-600">{metrics.completed}</div>
                        <div className="text-gray-500">Done</div>
                      </div>
                      <div className="text-center">
                        <div className="font-medium text-red-600">{metrics.failed}</div>
                        <div className="text-gray-500">Failed</div>
                      </div>
                    </div>

                    {/* Progress bar for active jobs */}
                    {(metrics.active > 0 || metrics.waiting > 0) && (
                      <div className="space-y-1">
                        <div className="flex justify-between text-xs text-gray-500">
                          <span>Processing</span>
                          <span>{activePercent}%</span>
                        </div>
                        <Progress value={activePercent} className="h-1.5" />
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}

          {/* Overall Queue Health */}
          <div className="pt-4 border-t border-gray-200">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">Overall Status</span>
              <div className="flex items-center gap-2">
                {hasActiveJobs ? (
                  <>
                    <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                    <span className="text-blue-600 font-medium">Processing</span>
                  </>
                ) : (
                  <>
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-green-600 font-medium">All Clear</span>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}