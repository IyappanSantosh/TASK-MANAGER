import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { X, Eye } from "lucide-react";

interface Task {
  id: string;
  title: string;
  description: string;
  priority: "low" | "medium" | "high";
  status: "pending" | "processing" | "completed";
  createdAt: string;
  images: Array<{
    id: string;
    originalUrl: string;
    thumbnailUrl: string;
    fileName: string;
  }>;
  emailLogs: Array<{
    id: string;
    type: string;
    status: string;
    recipient: string;
    createdAt: string;
    error?: string;
  }>;
}

interface TaskDetailModalProps {
  task: Task;
  isOpen: boolean;
  onClose: () => void;
}

export function TaskDetailModal({ task, isOpen, onClose }: TaskDetailModalProps) {
  const { toast } = useToast();

  const updateStatusMutation = useMutation({
    mutationFn: async (status: string) => {
      const response = await fetch(`/api/tasks/${task.id}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });

      if (!response.ok) {
        throw new Error("Failed to update task status");
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      toast({
        title: "Status Updated",
        description: "Task status has been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const retryEmailMutation = useMutation({
    mutationFn: async (emailLogId: string) => {
      const response = await fetch(`/api/email-logs/${emailLogId}/retry`, {
        method: "POST",
      });

      if (!response.ok) {
        throw new Error("Failed to retry email");
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      toast({
        title: "Email Retry",
        description: "Email has been queued for retry.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-red-100 text-red-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      case "low": return "bg-green-100 text-green-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed": return "bg-green-100 text-green-800";
      case "processing": return "bg-blue-100 text-blue-800";
      case "pending": return "bg-orange-100 text-orange-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getEmailStatusColor = (status: string) => {
    switch (status) {
      case "sent": return "bg-green-100 text-green-800";
      case "pending": return "bg-yellow-100 text-yellow-800";
      case "failed": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader className="border-b border-gray-200 pb-4">
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="text-xl font-semibold text-gray-900">
                {task.title}
              </DialogTitle>
              <div className="flex items-center space-x-3 mt-2">
                <Badge className={getPriorityColor(task.priority)}>
                  {task.priority} Priority
                </Badge>
                <Badge className={getStatusColor(task.status)}>
                  {task.status}
                </Badge>
                <span className="text-sm text-gray-500">
                  Created {new Date(task.createdAt).toLocaleDateString()}
                </span>
              </div>
            </div>
          </div>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Task Description */}
          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-3">Description</h3>
            <p className="text-gray-600 leading-relaxed">
              {task.description || "No description provided."}
            </p>
          </div>

          {/* Task Images */}
          {task.images.length > 0 && (
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-3">Attachments</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {task.images.map((image) => (
                  <div key={image.id} className="relative group">
                    <img
                      src={image.thumbnailUrl}
                      alt={image.fileName}
                      className="w-full h-32 object-cover rounded-lg border border-gray-200"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-200 rounded-lg flex items-center justify-center">
                      <Button
                        variant="secondary"
                        size="sm"
                        className="opacity-0 group-hover:opacity-100 transition-opacity"
                        asChild
                      >
                        <a href={image.originalUrl} target="_blank" rel="noopener noreferrer">
                          <Eye className="w-4 h-4" />
                        </a>
                      </Button>
                    </div>
                    <div className="mt-2">
                      <p className="text-sm text-gray-600 truncate">{image.fileName}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Processing Status */}
          {task.status === "processing" && (
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-3">Processing Status</h3>
              <Card>
                <CardContent className="pt-4">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-medium text-gray-700">Task Processing</span>
                    <span className="text-sm text-gray-600">65% complete</span>
                  </div>
                  <Progress value={65} className="mb-4" />
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div className="text-center">
                      <div className="font-semibold text-gray-900">Queue Position</div>
                      <div className="text-gray-600">#2</div>
                    </div>
                    <div className="text-center">
                      <div className="font-semibold text-gray-900">Estimated Time</div>
                      <div className="text-gray-600">3 min</div>
                    </div>
                    <div className="text-center">
                      <div className="font-semibold text-gray-900">Worker ID</div>
                      <div className="text-gray-600 font-mono">task-001</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Email Logs */}
          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-3">Email Notifications</h3>
            <div className="space-y-3">
              {task.emailLogs.length === 0 ? (
                <p className="text-gray-500">No email notifications yet.</p>
              ) : (
                task.emailLogs.map((log) => (
                  <Card key={log.id} className={log.status === "failed" ? "border-red-200 bg-red-50" : ""}>
                    <CardContent className="pt-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <span className="text-sm font-medium text-gray-900">
                              {log.type.replace("_", " ").replace(/\b\w/g, l => l.toUpperCase())}
                            </span>
                            <Badge className={getEmailStatusColor(log.status)}>
                              {log.status}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 mb-1">To: {log.recipient}</p>
                          {log.error && (
                            <p className="text-xs text-red-600 mb-1">Error: {log.error}</p>
                          )}
                          <p className="text-xs text-gray-500">
                            {new Date(log.createdAt).toLocaleString()}
                          </p>
                        </div>
                        {log.status === "failed" && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => retryEmailMutation.mutate(log.id)}
                            disabled={retryEmailMutation.isPending}
                          >
                            Retry
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </div>
        </div>

        <div className="border-t border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div className="flex space-x-3">
              {task.status !== "completed" && (
                <Button
                  onClick={() => updateStatusMutation.mutate("completed")}
                  disabled={updateStatusMutation.isPending}
                >
                  Mark Complete
                </Button>
              )}
              {task.status === "completed" && (
                <Button
                  variant="outline"
                  onClick={() => updateStatusMutation.mutate("pending")}
                  disabled={updateStatusMutation.isPending}
                >
                  Reset to Pending
                </Button>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
