import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { Upload, X, Image as ImageIcon, FileText, AlertCircle } from "lucide-react";
import { validateImageFile, createFilePreview, formatFileSize } from "@/lib/utils";
import { VALIDATION, UPLOAD_LIMITS } from "@/lib/constants";

const taskFormSchema = z.object({
  title: z.string()
    .min(VALIDATION.TITLE_MIN_LENGTH, "Title is required")
    .max(VALIDATION.TITLE_MAX_LENGTH, `Title must be less than ${VALIDATION.TITLE_MAX_LENGTH} characters`),
  description: z.string()
    .max(VALIDATION.DESCRIPTION_MAX_LENGTH, `Description must be less than ${VALIDATION.DESCRIPTION_MAX_LENGTH} characters`)
    .optional(),
  priority: z.enum(["low", "medium", "high"]).default("medium"),
  processingType: z.enum(["fast", "standard", "slow"]).default("standard"),
});

type TaskFormData = z.infer<typeof taskFormSchema>;

interface FileWithPreview {
  file: File;
  preview: string;
  id: string;
}

interface TaskFormProps {
  onSuccess: () => void;
}

export function TaskForm({ onSuccess }: TaskFormProps) {
  const [selectedFiles, setSelectedFiles] = useState<FileWithPreview[]>([]);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isProcessingFiles, setIsProcessingFiles] = useState(false);
  const [duplicateCheckLoading, setDuplicateCheckLoading] = useState(false);
  const { toast } = useToast();

  const form = useForm<TaskFormData>({
    resolver: zodResolver(taskFormSchema),
    defaultValues: {
      title: "",
      description: "",
      priority: "medium",
      processingType: "standard",
    },
  });

  const createTaskMutation = useMutation({
    mutationFn: async (data: TaskFormData & { files: File[] }) => {
      // Check for duplicate title first
      setDuplicateCheckLoading(true);
      try {
        const existingTasksResponse = await fetch("/api/tasks");
        if (existingTasksResponse.ok) {
          const existingTasks = await existingTasksResponse.json();
          const isDuplicate = existingTasks.some((task: any) => 
            task.title.toLowerCase().trim() === data.title.toLowerCase().trim()
          );
          
          if (isDuplicate) {
            throw new Error("A task with this title already exists. Please choose a different title.");
          }
        }
      } finally {
        setDuplicateCheckLoading(false);
      }

      const formData = new FormData();
      formData.append("title", data.title);
      if (data.description) formData.append("description", data.description);
      formData.append("priority", data.priority);
      formData.append("processingType", data.processingType);
      
      // Add files with progress tracking
      data.files.forEach((file, index) => {
        formData.append("images", file);
        setUploadProgress(((index + 1) / data.files.length) * 100);
      });

      const response = await fetch("/api/tasks", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to create task");
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "✅ Task Created Successfully",
        description: "Your task has been created and is now being processed.",
      });
      onSuccess();
      form.reset();
      setSelectedFiles([]);
      setUploadProgress(0);
    },
    onError: (error) => {
      setUploadProgress(0);
      toast({
        title: "❌ Task Creation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    
    if (selectedFiles.length + files.length > UPLOAD_LIMITS.MAX_FILES) {
      toast({
        title: "Too many files",
        description: `Maximum ${UPLOAD_LIMITS.MAX_FILES} files allowed. Currently selected: ${selectedFiles.length}`,
        variant: "destructive",
      });
      return;
    }

    setIsProcessingFiles(true);
    
    const processedFiles: FileWithPreview[] = [];
    
    for (const file of files) {
      const validation = validateImageFile(file);
      
      if (!validation.isValid) {
        toast({
          title: "Invalid file",
          description: validation.error,
          variant: "destructive",
        });
        continue;
      }

      try {
        const preview = await createFilePreview(file);
        processedFiles.push({
          file,
          preview,
          id: `${Date.now()}-${Math.random()}`
        });
      } catch (error) {
        toast({
          title: "Failed to process file",
          description: `Could not process ${file.name}. The file might be corrupted.`,
          variant: "destructive",
        });
      }
    }

    setSelectedFiles(prev => [...prev, ...processedFiles]);
    setIsProcessingFiles(false);
    
    // Clear the input
    event.target.value = '';
  };

  const removeFile = (id: string) => {
    setSelectedFiles(prev => prev.filter(f => f.id !== id));
  };

  const onSubmit = (data: TaskFormData) => {
    if (createTaskMutation.isPending || duplicateCheckLoading) return;
    
    const files = selectedFiles.map(f => f.file);
    createTaskMutation.mutate({ ...data, files });
  };

  // Clean up preview URLs when component unmounts
  useEffect(() => {
    return () => {
      selectedFiles.forEach(fileWithPreview => {
        URL.revokeObjectURL(fileWithPreview.preview);
      });
    };
  }, [selectedFiles]);

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Task Title *</FormLabel>
              <FormControl>
                <Input placeholder="Enter task title..." {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Describe the task requirements and acceptance criteria..."
                  rows={4}
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="priority"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Priority</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="processingType"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Processing Type</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select processing type" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="fast">Fast (2-3s)</SelectItem>
                    <SelectItem value="standard">Standard (5-10s)</SelectItem>
                    <SelectItem value="slow">Slow (15-30s)</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        {/* File Upload Section */}
        <div className="space-y-4">
          <FormLabel className="flex items-center gap-2">
            <ImageIcon className="w-4 h-4" />
            Attach Images (Optional)
            <span className="text-xs text-gray-500">
              Max {UPLOAD_LIMITS.MAX_FILES} files, {formatFileSize(UPLOAD_LIMITS.MAX_FILE_SIZE)} each
            </span>
          </FormLabel>
          
          {/* Upload Progress */}
          {(uploadProgress > 0 && uploadProgress < 100) && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Uploading...</span>
                <span className="text-gray-600">{uploadProgress.toFixed(0)}%</span>
              </div>
              <Progress value={uploadProgress} className="h-2" />
            </div>
          )}
          
          <div className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
            isProcessingFiles 
              ? 'border-blue-300 bg-blue-50' 
              : 'border-gray-300 hover:border-gray-400'
          }`}>
            <input
              type="file"
              multiple
              accept=".jpg,.jpeg,.png,image/jpeg,image/png"
              onChange={handleFileSelect}
              className="hidden"
              id="file-upload"
              disabled={isProcessingFiles || createTaskMutation.isPending}
            />
            <label htmlFor="file-upload" className={`cursor-pointer ${
              isProcessingFiles || createTaskMutation.isPending ? 'cursor-not-allowed opacity-50' : ''
            }`}>
              {isProcessingFiles ? (
                <>
                  <div className="w-12 h-12 mx-auto mb-4 animate-spin">
                    <div className="w-full h-full border-4 border-blue-200 border-t-blue-600 rounded-full"></div>
                  </div>
                  <p className="text-lg font-medium text-blue-900 mb-2">Processing Files...</p>
                  <p className="text-sm text-blue-600">Please wait while we validate your images</p>
                </>
              ) : (
                <>
                  <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-lg font-medium text-gray-900 mb-2">Upload Images</p>
                  <p className="text-sm text-gray-500">
                    Click to select files or drag and drop
                  </p>
                  <p className="text-xs text-gray-400 mt-2">
                    JPEG, PNG up to {formatFileSize(UPLOAD_LIMITS.MAX_FILE_SIZE)} each
                  </p>
                </>
              )}
            </label>
          </div>

          {/* Selected Files with Previews */}
          {selectedFiles.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-gray-700">
                  Selected Files ({selectedFiles.length}/{UPLOAD_LIMITS.MAX_FILES})
                </p>
                {selectedFiles.length > 0 && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => setSelectedFiles([])}
                    className="text-red-500 hover:text-red-700 text-xs"
                  >
                    Clear All
                  </Button>
                )}
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {selectedFiles.map((fileWithPreview) => (
                  <div key={fileWithPreview.id} className="relative group">
                    <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg border hover:bg-gray-100 transition-colors">
                      <div className="w-12 h-12 rounded-lg overflow-hidden bg-gray-200 flex-shrink-0">
                        <img
                          src={fileWithPreview.preview}
                          alt={fileWithPreview.file.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900 truncate">
                          {fileWithPreview.file.name}
                        </p>
                        <p className="text-xs text-gray-500">
                          {formatFileSize(fileWithPreview.file.size)}
                        </p>
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => removeFile(fileWithPreview.id)}
                        className="text-red-500 hover:text-red-700 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Submit Button */}
        <div className="flex items-center gap-4">
          <Button 
            type="submit" 
            disabled={createTaskMutation.isPending || duplicateCheckLoading || isProcessingFiles}
            className="flex-1"
          >
            {createTaskMutation.isPending ? (
              <>
                <div className="w-4 h-4 mr-2 animate-spin">
                  <div className="w-full h-full border-2 border-white border-t-transparent rounded-full"></div>
                </div>
                Creating Task...
              </>
            ) : duplicateCheckLoading ? (
              <>
                <AlertCircle className="w-4 h-4 mr-2" />
                Checking Title...
              </>
            ) : (
              <>
                <FileText className="w-4 h-4 mr-2" />
                Create Task
              </>
            )}
          </Button>
        </div>
      </form>
    </Form>
  );
}
