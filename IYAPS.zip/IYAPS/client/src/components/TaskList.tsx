import { useState, useMemo } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Eye, Upload, Clock, CheckCircle, AlertCircle, Image as ImageIcon } from "lucide-react";
import { TaskFilter, type TaskFilters } from "./TaskFilter";
import { STATUS_COLORS, PRIORITY_COLORS } from "@/lib/constants";
import { getRelativeTime, cn } from "@/lib/utils";

interface Task {
  id: string;
  title: string;
  description: string;
  priority: "low" | "medium" | "high";
  status: "pending" | "processing" | "completed";
  createdAt: string;
  images: Array<{
    id: string;
    originalUrl: string;
    thumbnailUrl: string;
    fileName: string;
  }>;
  emailLogs: Array<{
    id: string;
    type: string;
    status: string;
    recipient: string;
    createdAt: string;
  }>;
}

interface TaskListProps {
  tasks: Task[];
  isLoading: boolean;
  onTaskSelect: (task: Task) => void;
}

export function TaskList({ tasks, isLoading, onTaskSelect }: TaskListProps) {
  const [filters, setFilters] = useState<TaskFilters>({
    search: '',
    status: 'all',
    priority: 'all',
    sortBy: 'createdAt',
    sortOrder: 'desc'
  });

  // Filter and sort tasks
  const filteredAndSortedTasks = useMemo(() => {
    let filtered = tasks;

    // Apply search filter
    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      filtered = filtered.filter(task => 
        task.title.toLowerCase().includes(searchLower) ||
        task.description.toLowerCase().includes(searchLower)
      );
    }

    // Apply status filter
    if (filters.status !== 'all') {
      filtered = filtered.filter(task => task.status === filters.status);
    }

    // Apply priority filter
    if (filters.priority !== 'all') {
      filtered = filtered.filter(task => task.priority === filters.priority);
    }

    // Apply sorting
    filtered.sort((a, b) => {
      let valueA: any, valueB: any;

      switch (filters.sortBy) {
        case 'title':
          valueA = a.title;
          valueB = b.title;
          break;
        case 'priority':
          const priorityOrder = { high: 3, medium: 2, low: 1 };
          valueA = priorityOrder[a.priority];
          valueB = priorityOrder[b.priority];
          break;
        case 'status':
          const statusOrder = { pending: 1, processing: 2, completed: 3 };
          valueA = statusOrder[a.status];
          valueB = statusOrder[b.status];
          break;
        default:
          valueA = new Date(a.createdAt);
          valueB = new Date(b.createdAt);
      }

      if (filters.sortOrder === 'asc') {
        return valueA > valueB ? 1 : -1;
      } else {
        return valueA < valueB ? 1 : -1;
      }
    });

    return filtered;
  }, [tasks, filters]);
  if (isLoading) {
    return (
      <div className="space-y-4">
        {[...Array(3)].map((_, i) => (
          <Card key={i}>
            <CardContent className="pt-6">
              <div className="space-y-3">
                <Skeleton className="h-5 w-3/4" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (tasks.length === 0) {
    return (
      <div className="space-y-6">
        <TaskFilter 
          filters={filters}
          onFiltersChange={setFilters}
          totalTasks={0}
          filteredCount={0}
        />
        <Card>
          <CardContent className="pt-6">
            <div className="text-center py-8">
              <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No tasks found</h3>
              <p className="text-gray-500">Create your first task to get started.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (filteredAndSortedTasks.length === 0 && tasks.length > 0) {
    return (
      <div className="space-y-6">
        <TaskFilter 
          filters={filters}
          onFiltersChange={setFilters}
          totalTasks={tasks.length}
          filteredCount={0}
        />
        <Card>
          <CardContent className="pt-6">
            <div className="text-center py-8">
              <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No tasks match your filters</h3>
              <p className="text-gray-500">Try adjusting your search or filter criteria.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed": return <CheckCircle className="w-4 h-4" />;
      case "processing": return <Clock className="w-4 h-4" />;
      case "pending": return <AlertCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      <TaskFilter 
        filters={filters}
        onFiltersChange={setFilters}
        totalTasks={tasks.length}
        filteredCount={filteredAndSortedTasks.length}
      />
      
      <div className="space-y-4">
        {filteredAndSortedTasks.map((task) => (
        <Card key={task.id} className="hover:shadow-md transition-all duration-200 hover:border-gray-300">
          <CardContent className="pt-6">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center flex-wrap gap-2 mb-3">
                  <h3 className="text-lg font-semibold text-gray-900 min-w-0 flex-1">{task.title}</h3>
                  <div className="flex items-center gap-2">
                    <Badge className={cn("border", PRIORITY_COLORS[task.priority as keyof typeof PRIORITY_COLORS])}>
                      {task.priority}
                    </Badge>
                    <Badge className={cn("border flex items-center gap-1", STATUS_COLORS[task.status as keyof typeof STATUS_COLORS])}>
                      {getStatusIcon(task.status)}
                      {task.status}
                    </Badge>
                  </div>
                </div>
                
                {task.description && (
                  <p className="text-gray-600 mb-4 line-clamp-2">{task.description}</p>
                )}
                
                {/* Task Images */}
                {task.images.length > 0 && (
                  <div className="flex items-center gap-3 mb-4">
                    <div className="flex space-x-2">
                      {task.images.slice(0, 3).map((image) => (
                        <div key={image.id} className="relative group">
                          <img
                            src={image.thumbnailUrl}
                            alt={image.fileName}
                            className="w-16 h-16 rounded-lg object-cover border border-gray-200 hover:border-gray-300 transition-colors cursor-pointer"
                            onClick={() => onTaskSelect(task)}
                          />
                        </div>
                      ))}
                      {task.images.length > 3 && (
                        <div className="w-16 h-16 rounded-lg border border-gray-200 bg-gray-100 flex items-center justify-center">
                          <span className="text-xs text-gray-500 font-medium">+{task.images.length - 3}</span>
                        </div>
                      )}
                    </div>
                    <div className="flex items-center gap-1 text-xs text-gray-500">
                      <ImageIcon className="w-3 h-3" />
                      {task.images.length} image{task.images.length !== 1 ? 's' : ''}
                    </div>
                  </div>
                )}

                <div className="flex items-center space-x-6 text-sm text-gray-500">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {getRelativeTime(task.createdAt)}
                  </span>
                  {task.emailLogs.length > 0 && (
                    <span>{task.emailLogs.length} email{task.emailLogs.length !== 1 ? 's' : ''}</span>
                  )}
                </div>
              </div>
              
              <div className="flex items-center space-x-2 ml-4">
                <Button variant="ghost" size="sm" onClick={() => onTaskSelect(task)} className="hover:bg-gray-100">
                  <Eye className="w-4 h-4" />
                </Button>
              </div>
            </div>
            
            {/* Progress indicator for processing tasks */}
            {task.status === "processing" && (
              <div className="mt-4">
                <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
                  <span className="flex items-center gap-2">
                    <div className="w-4 h-4 animate-spin">
                      <div className="w-full h-full border-2 border-gray-300 border-t-blue-600 rounded-full"></div>
                    </div>
                    Processing task...
                  </span>
                  <span className="text-xs">~65% complete</span>
                </div>
                <Progress value={65} className="h-2" />
              </div>
            )}
          </CardContent>
        </Card>
        ))}
      </div>
    </div>
  );
}
