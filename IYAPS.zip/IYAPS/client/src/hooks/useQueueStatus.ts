import { useQuery } from "@tanstack/react-query";
import { API_ENDPOINTS, REFRESH_INTERVALS } from "@/lib/constants";

interface QueueMetrics {
  waiting: number;
  active: number;
  completed: number;
  failed: number;
}

interface QueueStatusData {
  taskProcessor: QueueMetrics | undefined;
  imageUpload: QueueMetrics | undefined;
  emailDispatch: QueueMetrics | undefined;
  isLoading: boolean;
  hasActiveJobs: boolean;
  totalJobs: number;
}

export function useQueueStatus(): QueueStatusData {
  const { data: taskProcessorMetrics, isLoading: taskProcessorLoading } = useQuery<QueueMetrics>({
    queryKey: [API_ENDPOINTS.QUEUE_METRICS('taskProcessor')],
    refetchInterval: REFRESH_INTERVALS.QUEUE_METRICS,
    staleTime: REFRESH_INTERVALS.QUEUE_METRICS - 1000,
  });

  const { data: imageUploadMetrics, isLoading: imageUploadLoading } = useQuery<QueueMetrics>({
    queryKey: [API_ENDPOINTS.QUEUE_METRICS('imageUpload')],
    refetchInterval: REFRESH_INTERVALS.QUEUE_METRICS,
    staleTime: REFRESH_INTERVALS.QUEUE_METRICS - 1000,
  });

  const { data: emailDispatchMetrics, isLoading: emailDispatchLoading } = useQuery<QueueMetrics>({
    queryKey: [API_ENDPOINTS.QUEUE_METRICS('emailDispatch')],
    refetchInterval: REFRESH_INTERVALS.QUEUE_METRICS,
    staleTime: REFRESH_INTERVALS.QUEUE_METRICS - 1000,
  });

  const isLoading = taskProcessorLoading || imageUploadLoading || emailDispatchLoading;
  
  const totalActive = (taskProcessorMetrics?.active || 0) + 
                     (imageUploadMetrics?.active || 0) + 
                     (emailDispatchMetrics?.active || 0);
                     
  const totalWaiting = (taskProcessorMetrics?.waiting || 0) + 
                      (imageUploadMetrics?.waiting || 0) + 
                      (emailDispatchMetrics?.waiting || 0);
                      
  const hasActiveJobs = totalActive > 0 || totalWaiting > 0;
  const totalJobs = totalActive + totalWaiting;

  return {
    taskProcessor: taskProcessorMetrics,
    imageUpload: imageUploadMetrics,
    emailDispatch: emailDispatchMetrics,
    isLoading,
    hasActiveJobs,
    totalJobs
  };
}