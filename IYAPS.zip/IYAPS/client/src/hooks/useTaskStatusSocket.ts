import { useEffect, useRef } from "react";
import { queryClient } from "@/lib/queryClient";
import { API_ENDPOINTS } from "@/lib/constants";

interface SocketEventData {
  type: string;
  task?: any;
  data?: any;
}

// This hook is prepared for future WebSocket reactivation
export function useTaskStatusSocket() {
  const socketRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const connect = () => {
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      return;
    }

    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}`;
      
      socketRef.current = new WebSocket(wsUrl);
      
      socketRef.current.onopen = () => {
        console.log('WebSocket connected');
        if (reconnectTimeoutRef.current) {
          clearTimeout(reconnectTimeoutRef.current);
          reconnectTimeoutRef.current = null;
        }
      };
      
      socketRef.current.onmessage = (event) => {
        try {
          const data: SocketEventData = JSON.parse(event.data);
          handleSocketMessage(data);
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      };
      
      socketRef.current.onclose = () => {
        console.log('WebSocket disconnected');
        socketRef.current = null;
        
        // Attempt to reconnect after 5 seconds
        if (!reconnectTimeoutRef.current) {
          reconnectTimeoutRef.current = setTimeout(() => {
            console.log('Attempting to reconnect WebSocket...');
            connect();
          }, 5000);
        }
      };
      
      socketRef.current.onerror = (error) => {
        console.error('WebSocket error:', error);
      };
    } catch (error) {
      console.error('Failed to create WebSocket connection:', error);
    }
  };

  const handleSocketMessage = (data: SocketEventData) => {
    switch (data.type) {
      case 'task_created':
      case 'task_status_updated':
        // Invalidate tasks cache to refetch updated data
        queryClient.invalidateQueries({ queryKey: [API_ENDPOINTS.TASKS] });
        break;
      case 'queue_updated':
        // Invalidate queue metrics
        queryClient.invalidateQueries({ queryKey: ['/api/queues'] });
        break;
      default:
        console.log('Unknown socket event:', data.type);
    }
  };

  const disconnect = () => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }
    
    if (socketRef.current) {
      socketRef.current.close();
      socketRef.current = null;
    }
  };

  useEffect(() => {
    // For now, WebSocket is disabled - this is prepared for future reactivation
    // connect();
    
    return () => {
      disconnect();
    };
  }, []);

  return {
    isConnected: socketRef.current?.readyState === WebSocket.OPEN,
    connect,
    disconnect
  };
}