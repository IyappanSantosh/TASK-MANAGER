// Task Management App Constants

export const TASK_STATUS = {
  PENDING: 'pending',
  PROCESSING: 'processing',
  COMPLETED: 'completed'
} as const;

export const TASK_PRIORITY = {
  LOW: 'low',
  MEDIUM: 'medium',
  HIGH: 'high'
} as const;

export const PROCESSING_TYPE = {
  FAST: 'fast',
  STANDARD: 'standard',
  SLOW: 'slow'
} as const;

export const EMAIL_STATUS = {
  PENDING: 'pending',
  SENT: 'sent',
  FAILED: 'failed'
} as const;

// UI Constants
export const STATUS_COLORS = {
  [TASK_STATUS.PENDING]: 'bg-orange-100 text-orange-800 border-orange-200',
  [TASK_STATUS.PROCESSING]: 'bg-blue-100 text-blue-800 border-blue-200',
  [TASK_STATUS.COMPLETED]: 'bg-green-100 text-green-800 border-green-200'
} as const;

export const PRIORITY_COLORS = {
  [TASK_PRIORITY.LOW]: 'bg-green-100 text-green-800 border-green-200',
  [TASK_PRIORITY.MEDIUM]: 'bg-yellow-100 text-yellow-800 border-yellow-200',
  [TASK_PRIORITY.HIGH]: 'bg-red-100 text-red-800 border-red-200'
} as const;

// File Upload Constants
export const UPLOAD_LIMITS = {
  MAX_FILE_SIZE: 5 * 1024 * 1024, // 5MB
  MAX_FILES: 5,
  ACCEPTED_TYPES: ['image/jpeg', 'image/jpg', 'image/png']
} as const;

// Queue Refresh Intervals
export const REFRESH_INTERVALS = {
  QUEUE_METRICS: 5000, // 5 seconds
  TASKS: 30000 // 30 seconds
} as const;

// Validation Constants
export const VALIDATION = {
  TITLE_MAX_LENGTH: 100,
  DESCRIPTION_MAX_LENGTH: 1000,
  TITLE_MIN_LENGTH: 1
} as const;

// API Endpoints
export const API_ENDPOINTS = {
  TASKS: '/api/tasks',
  QUEUE_METRICS: (queueName: string) => `/api/queues/${queueName}/metrics`,
  EMAIL_LOGS: (taskId: string) => `/api/email-logs/${taskId}`,
  EMAIL_RETRY: (emailId: string) => `/api/email-logs/${emailId}/retry`,
  TASK_STATUS: (taskId: string) => `/api/tasks/${taskId}/status`
} as const;