let socket: WebSocket | null = null;
let reconnectTimeout: NodeJS.Timeout | null = null;
const listeners: Map<string, Array<(data: any) => void>> = new Map();

export function connectWebSocket() {
  if (socket?.readyState === WebSocket.OPEN) {
    return socket;
  }

  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const wsUrl = `${protocol}//${window.location.host}`;
  
  socket = new WebSocket(wsUrl);
  
  socket.onopen = () => {
    console.log('WebSocket connected');
    if (reconnectTimeout) {
      clearTimeout(reconnectTimeout);
      reconnectTimeout = null;
    }
  };
  
  socket.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      const eventListeners = listeners.get(data.type) || [];
      eventListeners.forEach(listener => listener(data));
    } catch (error) {
      console.error('Error parsing WebSocket message:', error);
    }
  };
  
  socket.onclose = () => {
    console.log('WebSocket disconnected');
    socket = null;
    
    // Attempt to reconnect after 5 seconds
    if (!reconnectTimeout) {
      reconnectTimeout = setTimeout(() => {
        console.log('Attempting to reconnect WebSocket...');
        connectWebSocket();
      }, 5000);
    }
  };
  
  socket.onerror = (error) => {
    console.error('WebSocket error:', error);
  };
  
  return socket;
}

export function addSocketListener(eventType: string, listener: (data: any) => void) {
  if (!listeners.has(eventType)) {
    listeners.set(eventType, []);
  }
  listeners.get(eventType)!.push(listener);
  
  // Return cleanup function
  return () => {
    const eventListeners = listeners.get(eventType);
    if (eventListeners) {
      const index = eventListeners.indexOf(listener);
      if (index > -1) {
        eventListeners.splice(index, 1);
      }
    }
  };
}

export function removeSocketListener(eventType: string, listener: (data: any) => void) {
  const eventListeners = listeners.get(eventType);
  if (eventListeners) {
    const index = eventListeners.indexOf(listener);
    if (index > -1) {
      eventListeners.splice(index, 1);
    }
  }
}

// Initialize WebSocket connection when module loads
if (typeof window !== 'undefined') {
  connectWebSocket();
}
