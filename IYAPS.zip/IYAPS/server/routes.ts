import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTaskSchema } from "@shared/schema";
import { z } from "zod";
import multer from "multer";
import path from "path";
import fs from "fs/promises";
import { v4 as uuidv4 } from "uuid";
import { initializeQueues, addTaskToQueue } from "./utils/queue.js";
// import { WebSocketServer } from "ws"; // Temporarily disabled

// Configure multer for file uploads
const uploadDir = path.join(process.cwd(), "server", "uploads");
const upload = multer({
  dest: uploadDir,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    // Enhanced file type checking for JPEG variations
    const allowedMimeTypes = ["image/jpeg", "image/jpg", "image/png"];
    const fileExtension = file.originalname.toLowerCase().split('.').pop();
    const allowedExtensions = ['jpg', 'jpeg', 'png'];
    
    if (allowedMimeTypes.includes(file.mimetype) || allowedExtensions.includes(fileExtension || '')) {
      cb(null, true);
    } else {
      cb(new Error("Only JPEG and PNG files are allowed"));
    }
  },
});

// Ensure upload directory exists
async function ensureUploadDir() {
  try {
    await fs.access(uploadDir);
  } catch {
    await fs.mkdir(uploadDir, { recursive: true });
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Initialize queues
  const queues = await initializeQueues();
  
  // Ensure upload directory exists
  await ensureUploadDir();
  
  // Mock broadcast function (WebSocket disabled for now)
  function broadcastUpdate(data: any) {
    console.log("Broadcast update:", data.type);
  }

  // Serve uploaded files
  app.use("/uploads", (req, res, next) => {
    const filePath = path.join(uploadDir, req.path);
    res.sendFile(filePath, (err) => {
      if (err) {
        res.status(404).json({ message: "File not found" });
      }
    });
  });

  // GET /api/tasks - List all tasks
  app.get("/api/tasks", async (req, res) => {
    try {
      const allTasks = await storage.getTasks();
      res.json(allTasks);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  // GET /api/tasks/:id - Get specific task
  app.get("/api/tasks/:id", async (req, res) => {
    try {
      const task = await storage.getTaskById(req.params.id);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      res.json(task);
    } catch (error) {
      console.error("Error fetching task:", error);
      res.status(500).json({ message: "Failed to fetch task" });
    }
  });

  // POST /api/tasks - Create new task
  app.post("/api/tasks", upload.array("images", 5), async (req, res) => {
    try {
      // Validate task data
      const taskData = insertTaskSchema.parse({
        title: req.body.title,
        description: req.body.description || null,
        priority: req.body.priority || "medium",
        processingType: req.body.processingType || "standard",
      });

      // Create task
      const newTask = await storage.createTask(taskData);

      // Handle image uploads if any
      const files = req.files as Express.Multer.File[];
      if (files && files.length > 0) {
        for (const file of files) {
          const fileName = `${uuidv4()}-${file.originalname}`;
          const originalPath = path.join(uploadDir, fileName);
          const thumbnailPath = path.join(uploadDir, `thumb-${fileName}`);
          
          // Move uploaded file to permanent location
          await fs.rename(file.path, originalPath);
          
          // Save image record to database
          await storage.createImage({
            taskId: newTask.id,
            originalUrl: `/uploads/${fileName}`,
            thumbnailUrl: `/uploads/thumb-${fileName}`,
            fileName: file.originalname,
            fileSize: file.size,
          });

          // Add to image upload queue for thumbnail generation
          await addTaskToQueue("imageUpload", {
            taskId: newTask.id,
            originalPath,
            thumbnailPath,
            fileName,
          });
        }
      }

      // Add to task processor queue
      await addTaskToQueue("taskProcessor", {
        taskId: newTask.id,
        processingType: taskData.processingType,
      });

      // Add to email dispatch queue
      await addTaskToQueue("emailDispatch", {
        taskId: newTask.id,
        type: "task_created",
        recipient: "user@example.com", // In real app, get from user context
      });

      // Broadcast task creation to WebSocket clients
      broadcastUpdate({
        type: "task_created",
        task: newTask,
      });

      res.status(201).json(newTask);
    } catch (error) {
      console.error("Error creating task:", error);
      
      // Clean up uploaded files on error
      const files = req.files as Express.Multer.File[];
      if (files) {
        for (const file of files) {
          try {
            await fs.unlink(file.path);
          } catch {}
        }
      }
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid task data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create task" });
    }
  });

  // PATCH /api/tasks/:id/status - Update task status
  app.patch("/api/tasks/:id/status", async (req, res) => {
    try {
      const { status } = req.body;
      
      if (!["pending", "processing", "completed"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }

      const updatedTask = await storage.updateTaskStatus(req.params.id, status);
      if (!updatedTask) {
        return res.status(404).json({ message: "Task not found" });
      }

      // Add to email dispatch queue for status change
      await addTaskToQueue("emailDispatch", {
        taskId: updatedTask.id,
        type: "status_changed",
        recipient: "user@example.com",
        status,
      });

      // Broadcast status update to WebSocket clients
      broadcastUpdate({
        type: "task_status_updated",
        task: updatedTask,
      });

      res.json(updatedTask);
    } catch (error) {
      console.error("Error updating task status:", error);
      res.status(500).json({ message: "Failed to update task status" });
    }
  });

  // GET /api/queues/:name/metrics - Get queue metrics
  app.get("/api/queues/:name/metrics", async (req, res) => {
    try {
      const queueName = req.params.name;
      const queue = queues[queueName as keyof typeof queues];
      
      if (!queue) {
        return res.status(404).json({ message: "Queue not found" });
      }

      const waiting = await queue.getWaiting();
      const active = await queue.getActive();
      const completed = await queue.getCompleted();
      const failed = await queue.getFailed();

      res.json({
        waiting: waiting.length,
        active: active.length,
        completed: completed.length,
        failed: failed.length,
      });
    } catch (error) {
      console.error("Error fetching queue metrics:", error);
      res.status(500).json({ message: "Failed to fetch queue metrics" });
    }
  });

  // GET /api/email-logs/:taskId - Get email logs for a task
  app.get("/api/email-logs/:taskId", async (req, res) => {
    try {
      const emailLogs = await storage.getEmailLogsByTaskId(req.params.taskId);
      res.json(emailLogs);
    } catch (error) {
      console.error("Error fetching email logs:", error);
      res.status(500).json({ message: "Failed to fetch email logs" });
    }
  });

  // POST /api/email-logs/:id/retry - Retry failed email
  app.post("/api/email-logs/:id/retry", async (req, res) => {
    try {
      const emailLog = await storage.updateEmailLog(req.params.id, {
        status: "pending",
        error: null,
      });

      if (!emailLog) {
        return res.status(404).json({ message: "Email log not found" });
      }

      // Add back to email dispatch queue
      await addTaskToQueue("emailDispatch", {
        taskId: emailLog.taskId,
        type: emailLog.type,
        recipient: emailLog.recipient,
        emailLogId: emailLog.id,
      });

      res.json(emailLog);
    } catch (error) {
      console.error("Error retrying email:", error);
      res.status(500).json({ message: "Failed to retry email" });
    }
  });

  return httpServer;
}
