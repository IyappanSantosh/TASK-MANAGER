import { 
  tasks, images, emailLogs, 
  type Task, type InsertTask, 
  type Image, type InsertImage,
  type EmailLog, type InsertEmailLog,
  type User, type InsertUser 
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
  // User methods (keeping existing interface)
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Task methods
  getTasks(): Promise<(Task & { images: Image[]; emailLogs: EmailLog[] })[]>;
  getTaskById(id: string): Promise<(Task & { images: Image[]; emailLogs: EmailLog[] }) | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTaskStatus(id: string, status: "pending" | "processing" | "completed"): Promise<Task | undefined>;

  // Image methods
  createImage(image: InsertImage): Promise<Image>;
  getImagesByTaskId(taskId: string): Promise<Image[]>;

  // Email log methods
  createEmailLog(emailLog: InsertEmailLog): Promise<EmailLog>;
  updateEmailLog(id: string, updates: Partial<EmailLog>): Promise<EmailLog | undefined>;
  getEmailLogsByTaskId(taskId: string): Promise<EmailLog[]>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: string): Promise<User | undefined> {
    // Mock implementation for now - not using tasks table for users
    return undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    // Mock implementation for now
    return undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Mock implementation for now
    return { id: "1", username: insertUser.username, password: insertUser.password };
  }

  // Task methods
  async getTasks(): Promise<(Task & { images: Image[]; emailLogs: EmailLog[] })[]> {
    const tasksResult = await db.query.tasks.findMany({
      with: {
        images: true,
        emailLogs: {
          orderBy: [desc(emailLogs.createdAt)],
        },
      },
      orderBy: [desc(tasks.createdAt)],
    });
    return tasksResult;
  }

  async getTaskById(id: string): Promise<(Task & { images: Image[]; emailLogs: EmailLog[] }) | undefined> {
    const task = await db.query.tasks.findFirst({
      where: eq(tasks.id, id),
      with: {
        images: true,
        emailLogs: {
          orderBy: [desc(emailLogs.createdAt)],
        },
      },
    });
    return task;
  }

  async createTask(task: InsertTask): Promise<Task> {
    const [newTask] = await db
      .insert(tasks)
      .values(task)
      .returning();
    return newTask;
  }

  async updateTaskStatus(id: string, status: "pending" | "processing" | "completed"): Promise<Task | undefined> {
    const [updatedTask] = await db
      .update(tasks)
      .set({ status, updatedAt: new Date() })
      .where(eq(tasks.id, id))
      .returning();
    return updatedTask;
  }

  // Image methods
  async createImage(image: InsertImage): Promise<Image> {
    const [newImage] = await db
      .insert(images)
      .values(image)
      .returning();
    return newImage;
  }

  async getImagesByTaskId(taskId: string): Promise<Image[]> {
    return db.select().from(images).where(eq(images.taskId, taskId));
  }

  // Email log methods
  async createEmailLog(emailLog: InsertEmailLog): Promise<EmailLog> {
    const [newEmailLog] = await db
      .insert(emailLogs)
      .values(emailLog)
      .returning();
    return newEmailLog;
  }

  async updateEmailLog(id: string, updates: Partial<EmailLog>): Promise<EmailLog | undefined> {
    const [updatedEmailLog] = await db
      .update(emailLogs)
      .set(updates)
      .where(eq(emailLogs.id, id))
      .returning();
    return updatedEmailLog;
  }

  async getEmailLogsByTaskId(taskId: string): Promise<EmailLog[]> {
    return db.select().from(emailLogs).where(eq(emailLogs.taskId, taskId));
  }
}

export const storage = new DatabaseStorage();
