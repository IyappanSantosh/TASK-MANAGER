import nodemailer from "nodemailer";

// Create transporter based on environment
const createTransporter = () => {
  // Use environment variables for SMTP configuration
  const smtpHost = process.env.SMTP_HOST || "localhost";
  const smtpPort = parseInt(process.env.SMTP_PORT || "1025");
  const smtpUser = process.env.SMTP_USER || "";
  const smtpPass = process.env.SMTP_PASS || "";
  
  // Default to Mailhog for development
  if (!smtpHost || smtpHost === "localhost") {
    console.log("Using Mailhog/development SMTP configuration");
    return nodemailer.createTransport({
      host: "localhost",
      port: 1025,
      ignoreTLS: true,
    });
  }
  
  // Production SMTP configuration
  return nodemailer.createTransport({
    host: smtpHost,
    port: smtpPort,
    secure: smtpPort === 465,
    auth: smtpUser ? {
      user: smtpUser,
      pass: smtpPass,
    } : undefined,
  });
};

const transporter = createTransporter();

export async function sendEmail({ to, subject, text, html }) {
  const mailOptions = {
    from: process.env.FROM_EMAIL || "noreply@taskflow.com",
    to,
    subject,
    text,
    html,
  };
  
  try {
    const result = await transporter.sendMail(mailOptions);
    console.log(`Email sent successfully to ${to}:`, result.messageId);
    return result;
  } catch (error) {
    console.error(`Failed to send email to ${to}:`, error);
    throw error;
  }
}

// Test email configuration
export async function testEmailConnection() {
  try {
    await transporter.verify();
    console.log("Email transporter is ready");
    return true;
  } catch (error) {
    console.error("Email transporter configuration error:", error);
    return false;
  }
}
