interface MockQueue {
  getWaiting: () => Promise<any[]>;
  getActive: () => Promise<any[]>;
  getCompleted: () => Promise<any[]>;
  getFailed: () => Promise<any[]>;
}

interface QueueSet {
  taskProcessor: MockQueue;
  imageUpload: MockQueue;
  emailDispatch: MockQueue;
}

let redisConnection: any = null;
let taskProcessorQueue: any = null;
let imageUploadQueue: any = null;
let emailDispatchQueue: any = null;

// Workers
let taskProcessorWorker: any;
let imageUploadWorker: any;
let emailDispatchWorker: any;

export async function initializeQueues(): Promise<QueueSet> {
  // For now, skip Redis initialization completely
  console.log("Starting without queue functionality - Redis disabled");
  
  // Create mock queue objects to prevent null reference errors
  const mockQueue: MockQueue = {
    getWaiting: async () => [],
    getActive: async () => [],
    getCompleted: async () => [],
    getFailed: async () => [],
  };
  
  return {
    taskProcessor: mockQueue,
    imageUpload: mockQueue,
    emailDispatch: mockQueue,
  };
}

export async function addTaskToQueue(queueName: string, data: any): Promise<{ id: string; data: any }> {
  if (!redisConnection) {
    console.log(`Skipping queue operation for ${queueName} - Redis not available`);
    return { id: "mock", data };
  }

  try {
    const queues = {
      taskProcessor: taskProcessorQueue,
      imageUpload: imageUploadQueue,
      emailDispatch: emailDispatchQueue,
    };

    const queue = queues[queueName as keyof typeof queues];
    if (!queue) {
      console.log(`Queue ${queueName} not found - skipping`);
      return { id: "mock", data };
    }

    const job = await queue.add(queueName, data, {
      removeOnComplete: 100,
      removeOnFail: 50,
      attempts: 3,
      backoff: {
        type: "exponential",
        delay: 2000,
      },
    });

    console.log(`Job ${job.id} added to ${queueName} queue`);
    return job;
  } catch (error) {
    console.log(`Skipping queue operation for ${queueName} - Redis connection error`);
    return { id: "mock", data };
  }
}

// Graceful shutdown
export async function closeQueues() {
  if (taskProcessorWorker) await taskProcessorWorker.close();
  if (imageUploadWorker) await imageUploadWorker.close();
  if (emailDispatchWorker) await emailDispatchWorker.close();
  
  await taskProcessorQueue.close();
  await imageUploadQueue.close();
  await emailDispatchQueue.close();
  
  await redisConnection.quit();
}

// Handle graceful shutdown
process.on('SIGTERM', closeQueues);
process.on('SIGINT', closeQueues);
