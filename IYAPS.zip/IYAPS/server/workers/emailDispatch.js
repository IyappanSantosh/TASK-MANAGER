import { Worker } from "bullmq";
import { storage } from "../storage.ts";
import { sendEmail } from "../utils/mailer.js";

export function createEmailDispatchWorker(redisConnection) {
  return new Worker(
    "emailDispatch",
    async (job) => {
      const { taskId, type, recipient, status, emailLogId } = job.data;
      
      console.log(`Sending ${type} email for task ${taskId} to ${recipient}`);
      
      // Create or update email log
      let emailLog;
      if (emailLogId) {
        // This is a retry
        emailLog = await storage.updateEmailLog(emailLogId, {
          status: "pending",
          attemptCount: job.attemptsMade + 1,
        });
      } else {
        // New email
        emailLog = await storage.createEmailLog({
          taskId,
          type,
          recipient,
          status: "pending",
          attemptCount: job.attemptsMade + 1,
        });
      }
      
      try {
        // Get task details for email content
        const task = await storage.getTaskById(taskId);
        if (!task) {
          throw new Error(`Task ${taskId} not found`);
        }
        
        // Send email
        const emailResult = await sendEmail({
          to: recipient,
          subject: getEmailSubject(type, task),
          text: getEmailText(type, task, status),
          html: getEmailHtml(type, task, status),
        });
        
        // Update email log with success
        await storage.updateEmailLog(emailLog.id, {
          status: "sent",
          sentAt: new Date(),
          error: null,
        });
        
        console.log(`Email sent successfully for task ${taskId}`);
        
        return { 
          success: true, 
          taskId, 
          recipient,
          messageId: emailResult.messageId,
          sentAt: new Date().toISOString() 
        };
      } catch (error) {
        console.error(`Error sending email for task ${taskId}:`, error);
        
        // Update email log with failure
        await storage.updateEmailLog(emailLog.id, {
          status: "failed",
          error: error.message,
        });
        
        throw error;
      }
    },
    {
      connection: redisConnection,
      concurrency: 5,
    }
  );
}

function getEmailSubject(type, task) {
  switch (type) {
    case "task_created":
      return `New Task Created: ${task.title}`;
    case "task_completed":
      return `Task Completed: ${task.title}`;
    case "status_changed":
      return `Task Status Updated: ${task.title}`;
    default:
      return `Task Notification: ${task.title}`;
  }
}

function getEmailText(type, task, status) {
  const baseText = `Task: ${task.title}\nDescription: ${task.description || "No description"}\nPriority: ${task.priority}`;
  
  switch (type) {
    case "task_created":
      return `A new task has been created.\n\n${baseText}\n\nCreated: ${task.createdAt}`;
    case "task_completed":
      return `Your task has been completed successfully.\n\n${baseText}\n\nCompleted: ${new Date().toISOString()}`;
    case "status_changed":
      return `Task status has been updated to: ${status}\n\n${baseText}\n\nUpdated: ${new Date().toISOString()}`;
    default:
      return baseText;
  }
}

function getEmailHtml(type, task, status) {
  const baseHtml = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #333;">${task.title}</h2>
      <p><strong>Description:</strong> ${task.description || "No description"}</p>
      <p><strong>Priority:</strong> ${task.priority}</p>
      <p><strong>Status:</strong> ${task.status}</p>
    </div>
  `;
  
  switch (type) {
    case "task_created":
      return `
        <h1 style="color: #4F46E5;">New Task Created</h1>
        ${baseHtml}
        <p><strong>Created:</strong> ${task.createdAt}</p>
      `;
    case "task_completed":
      return `
        <h1 style="color: #10B981;">Task Completed</h1>
        ${baseHtml}
        <p><strong>Completed:</strong> ${new Date().toISOString()}</p>
      `;
    case "status_changed":
      return `
        <h1 style="color: #F59E0B;">Task Status Updated</h1>
        ${baseHtml}
        <p><strong>New Status:</strong> ${status}</p>
        <p><strong>Updated:</strong> ${new Date().toISOString()}</p>
      `;
    default:
      return baseHtml;
  }
}
