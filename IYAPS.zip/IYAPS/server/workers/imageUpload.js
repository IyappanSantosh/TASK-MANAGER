import { Worker } from "bullmq";
import sharp from "sharp";
import { storage } from "../storage.ts";

export function createImageUploadWorker(redisConnection) {
  return new Worker(
    "imageUpload",
    async (job) => {
      const { taskId, originalPath, thumbnailPath, fileName } = job.data;
      
      console.log(`Processing image for task ${taskId}: ${fileName}`);
      
      try {
        // Generate 256px thumbnail using Sharp
        await sharp(originalPath)
          .resize(256, 256, {
            fit: "inside",
            withoutEnlargement: true,
          })
          .jpeg({ quality: 80 })
          .toFile(thumbnailPath);
        
        console.log(`Thumbnail generated for task ${taskId}: ${fileName}`);
        
        return { 
          success: true, 
          taskId, 
          fileName,
          originalPath,
          thumbnailPath,
          processedAt: new Date().toISOString() 
        };
      } catch (error) {
        console.error(`Error processing image for task ${taskId}:`, error);
        throw error;
      }
    },
    {
      connection: redisConnection,
      concurrency: 2,
    }
  );
}
