import { Worker } from "bullmq";
import { storage } from "../storage.ts";
import { addTaskToQueue } from "../utils/queue.js";

export function createTaskProcessorWorker(redisConnection) {
  return new Worker(
    "taskProcessor",
    async (job) => {
      const { taskId, processingType } = job.data;
      
      console.log(`Processing task ${taskId} with type ${processingType}`);
      
      // Update task status to processing
      await storage.updateTaskStatus(taskId, "processing");
      
      // Simulate processing delay based on type
      const delays = {
        fast: 3000,      // 3 seconds
        standard: 7000,  // 7 seconds
        slow: 20000,     // 20 seconds
      };
      
      const delay = delays[processingType] || delays.standard;
      
      // Simulate work with progress updates
      const steps = 10;
      const stepDelay = delay / steps;
      
      for (let i = 1; i <= steps; i++) {
        await new Promise(resolve => setTimeout(resolve, stepDelay));
        
        // Update job progress
        await job.updateProgress((i / steps) * 100);
        
        console.log(`Task ${taskId} progress: ${(i / steps) * 100}%`);
      }
      
      // Mark task as completed
      await storage.updateTaskStatus(taskId, "completed");
      
      // Trigger completion email
      await addTaskToQueue("emailDispatch", {
        taskId,
        type: "task_completed",
        recipient: "user@example.com",
      });
      
      console.log(`Task ${taskId} completed successfully`);
      
      return { success: true, taskId, completedAt: new Date().toISOString() };
    },
    {
      connection: redisConnection,
      concurrency: 3,
    }
  );
}
